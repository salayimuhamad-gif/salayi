<?php

declare(strict_types=1);

use App\Modules\Identity\Http\Controllers\Account\ConsentController;
use App\Modules\Identity\Http\Controllers\Account\OnboardingController;
use App\Modules\Identity\Http\Controllers\Account\ProfileController;
use App\Modules\Identity\Http\Controllers\AccountTelegramLinkController;
use Illuminate\Support\Facades\Route;

/*
 * The signed-in account surface (spec §5).
 *
 * Loaded through the module loader's LocalizedRoutes wrapper like every other
 * public-module route file, so /account/onboarding exists in all three
 * locales exactly as /account/portfolio does.
 *
 * `telegram.linked` and not merely `auth`: onboarding is the first stop AFTER
 * the link completes, and an unlinked session arriving here is a registration
 * that has not finished — the gate sends it back to finish.
 */
Route::middleware(['auth', 'account.active', 'telegram.linked'])->group(function (): void {
    Route::get('/account/onboarding', [OnboardingController::class, 'show'])->name('account.onboarding');
    Route::post('/account/onboarding', [OnboardingController::class, 'store'])->name('account.onboarding.store');

    Route::get('/account/profile', [ProfileController::class, 'show'])->name('account.profile');
    Route::put('/account/profile', [ProfileController::class, 'update'])->name('account.profile.update');
    Route::post('/account/profile/photo', [ProfileController::class, 'storePhoto'])
        ->middleware('throttle:profile-photo')->name('account.profile.photo');
    Route::delete('/account/profile/photo', [ProfileController::class, 'destroyPhoto'])
        ->name('account.profile.photo.destroy');

    /*
     * v4 BLOCKER 6: contact-consent self service. Separate from the profile
     * because it IS separate — `contact_preference` on the profile says how
     * to reach somebody, this says whether they may be reached at all, and
     * putting them on one screen is how the two got confused in the first
     * place.
     */
    Route::get('/account/privacy', [ConsentController::class, 'show'])->name('account.privacy');
    Route::post('/account/privacy/withdraw', [ConsentController::class, 'withdraw'])
        ->name('account.privacy.withdraw');
    Route::post('/account/privacy/grant', [ConsentController::class, 'grant'])
        ->name('account.privacy.grant');
});

/*
 * The account-link surface (correction C1): `auth` WITHOUT the
 * `telegram.linked` gate, because this is where the gate SENDS people.
 * An unlinked-but-signed-in account must be able to reach exactly these
 * three routes, and nothing else personalised, until the link completes.
 */
Route::middleware(['auth', 'account.active'])->group(function (): void {
    Route::get('/account/telegram/link', [AccountTelegramLinkController::class, 'show'])
        ->name('account.telegram.link');
    Route::get('/account/telegram/link/poll', [AccountTelegramLinkController::class, 'poll'])
        ->middleware('throttle:telegram-link-poll')->name('account.telegram.link.poll');
    Route::post('/account/telegram/link/cancel', [AccountTelegramLinkController::class, 'cancel'])
        ->name('account.telegram.link.cancel');

    /*
     * v4 BLOCKER 1: minting a replacement token is now an explicit act, so
     * it is a POST with a name of its own rather than a side effect of
     * rendering the page.
     */
    Route::post('/account/telegram/link/restart', [AccountTelegramLinkController::class, 'restart'])
        ->name('account.telegram.link.restart');

    /*
     * v4 §5: the browser confirmation step. `confirm` is throttled on the
     * same bucket as the poll — it is reachable only with a parked
     * candidate and a matching handle, but it is the last gate before a
     * durable identity link and does not need to be cheap to hammer.
     */
    Route::post('/account/telegram/link/confirm', [AccountTelegramLinkController::class, 'confirm'])
        ->middleware('throttle:telegram-link-poll')->name('account.telegram.link.confirm');
    Route::post('/account/telegram/link/reject', [AccountTelegramLinkController::class, 'reject'])
        ->name('account.telegram.link.reject');
});
