<?php

declare(strict_types=1);

use App\Modules\Identity\Console\PruneTelegramIntents;
use Illuminate\Support\Facades\Schedule;

/*
 * Daily. Login material is short-lived by design, so nothing here is urgent —
 * but leaving it unbounded turns the login path into the slowest query on the
 * system eventually, and that is the worst place for one.
 */
Schedule::command(PruneTelegramIntents::class)
    ->dailyAt('03:20')
    ->withoutOverlapping(30)
    ->onOneServer();
