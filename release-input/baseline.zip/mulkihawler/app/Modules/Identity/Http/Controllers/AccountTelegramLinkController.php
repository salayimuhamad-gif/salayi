<?php

declare(strict_types=1);

namespace App\Modules\Identity\Http\Controllers;

use App\Modules\Identity\Models\TelegramLoginIntent;
use App\Modules\Identity\Services\TelegramRegistrar;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Linking Telegram to an EXISTING signed-in account (correction C1,
 * corrected again in v4 for BLOCKER 1 and §5).
 *
 * This page exists for exactly the person the review found stranded: an
 * email/password account minted before the Telegram era, now facing the
 * mandatory-link gate with no door. The gate (`EnsureTelegramLinked`)
 * sends them here; here they get a bot button, a live poll, and every
 * state the flow can end in — pending, awaiting confirmation, success,
 * expired, conflict, cancelled — each with a way forward.
 *
 * Two v4 corrections shape this controller:
 *
 *   BLOCKER 1 — rendering the page is no longer an EVENT. `show()` RESUMES
 *   the live session-bound intent instead of minting a replacement, so a
 *   refresh, a mobile tab eviction, a second tab or a back-button
 *   navigation all display the same token the person may already have open
 *   in Telegram. Minting is now something the person does on purpose, via
 *   `restart()`.
 *
 *   §5 — a Telegram Start no longer completes the link by itself. It parks
 *   a candidate identity that this page shows back to the person, and only
 *   a `confirm()` from this authenticated browser finalises it. The browser
 *   never receives the candidate's Telegram id: it receives an HMAC handle
 *   bound to the intent token, and sends that same handle back, so a
 *   candidate swapped between render and click is detected instead of
 *   silently linked.
 *
 * Session binding remains the security spine throughout: the intent is
 * minted bound to THIS user and THIS browser session, every read and write
 * below is scoped to that session, and completion regenerates the session
 * id.
 *
 * v5, BLOCKER 3: every redirect and JSON redirect URL in this journey now
 * resolves through `localized_route()`. An Arabic user completing the link
 * from /ar/account/telegram/link lands on /ar/account/profile, not on the
 * Sorani default — the locale comes from the active request (SetLocale has
 * already read the route default, the session and the user preference, in
 * that order), which is exactly the "active request/session, then user"
 * source the correction requires. Nothing hard-codes a prefix.
 */
final class AccountTelegramLinkController extends Controller
{
    public function __construct(private readonly TelegramRegistrar $registrar) {}

    public function show(Request $request): Response|RedirectResponse
    {
        $user = $request->user();

        // Already linked: there is nothing to do here, and no second link
        // to create. The profile shows the linked state.
        if ($user->telegram_verified_at !== null) {
            return redirect()->to(localized_route('account.profile'));
        }

        $intent = $this->registrar->resumeOrBeginAccountLink(
            $user,
            $request->session()->getId(),
            $this->hash($request->ip()),
            $this->hash($request->userAgent()),
        );

        return Inertia::render('Account/TelegramLink', $this->payload($intent));
    }

    /**
     * The person asks for a NEW token, on purpose.
     *
     * BLOCKER 1's whole point is that this is the only browser-initiated
     * path that invalidates a live intent. It is a POST because it destroys
     * something.
     */
    public function restart(Request $request): RedirectResponse
    {
        $user = $request->user();

        if ($user->telegram_verified_at !== null) {
            return redirect()->to(localized_route('account.profile'));
        }

        $this->registrar->resumeOrBeginAccountLink(
            $user,
            $request->session()->getId(),
            $this->hash($request->ip()),
            $this->hash($request->userAgent()),
            restart: true,
        );

        return redirect()->to(localized_route('account.telegram.link'));
    }

    /**
     * The browser's heartbeat. Answers ONLY for the session that minted
     * the intent, ONLY for this user, ONLY for the link purpose — and
     * names the state instead of leaving the person polling forever.
     */
    public function poll(Request $request): JsonResponse
    {
        $user = $request->user();

        $intent = $this->currentIntent($request);

        if ($intent === null) {
            /*
             * No intent this session may speak for. If the account is in
             * fact linked — completed in another tab, or by an earlier
             * intent — say so rather than leaving this tab pending forever.
             */
            $linked = $user->fresh()->telegram_verified_at !== null;

            return response()->json([
                'state' => $linked ? 'completed' : 'pending',
                'redirect' => $linked ? localized_route('account.profile') : null,
            ]);
        }

        if ($intent->result === TelegramLoginIntent::RESULT_CONFLICT) {
            return response()->json(['state' => 'conflict']);
        }

        if ($intent->cancelled_at !== null) {
            return response()->json(['state' => 'cancelled']);
        }

        if ($intent->consumed_at !== null && $user->fresh()->telegram_verified_at !== null) {
            /*
             * The link is real. Rotate the session id before telling the
             * browser: the pre-link session id has been sitting in a poll
             * loop and in the intent fingerprint's derivation input; the
             * post-link session gets a fresh one.
             */
            $request->session()->regenerate();

            return response()->json([
                'state' => 'completed',
                'redirect' => localized_route('account.profile'),
            ]);
        }

        /*
         * §5: a candidate is parked and the person has to look at it. This
         * is checked BEFORE expiry so somebody who pressed Start at the
         * last second is not told "expired" while their confirmation is
         * sitting there — `confirm()` re-checks expiry under a lock and is
         * the authority on whether it is too late.
         */
        if ($intent->candidate_telegram_id !== null) {
            return response()->json([
                'state' => 'awaiting_confirmation',
                'candidate' => $intent->candidatePayload(),
                'candidate_handle' => $intent->candidateHandle(),
            ]);
        }

        if (! $intent->expires_at->isFuture()) {
            return response()->json(['state' => 'expired']);
        }

        return response()->json(['state' => 'pending']);
    }

    /**
     * §5: the person confirms, in the browser that started this, that the
     * Telegram account which pressed Start is theirs.
     *
     * The handle the browser echoes back is what makes this a confirmation
     * of a SPECIFIC identity rather than a blanket "yes, link whatever
     * arrived".
     */
    public function confirm(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'candidate_handle' => ['required', 'string', 'size:64'],
        ]);

        $intent = $this->currentIntent($request);

        if ($intent === null || ! $intent->candidateHandleMatches($validated['candidate_handle'])) {
            return response()->json(['state' => 'candidate_changed'], 409);
        }

        $result = $this->registrar->confirmAccountLink(
            $request->user(),
            $request->session()->getId(),
            (string) $intent->candidate_telegram_id,
        );

        if (! $result['ok']) {
            return response()->json([
                'state' => match ($result['reason'] ?? '') {
                    'conflict' => 'conflict',
                    'candidate_changed' => 'candidate_changed',
                    default => 'expired',
                },
            ], 409);
        }

        $request->session()->regenerate();

        return response()->json([
            'state' => 'completed',
            'redirect' => localized_route('account.profile'),
        ]);
    }

    /**
     * §5: "that is not me." The candidate is discarded and the intent dies
     * with it — a stranger got hold of this token, so the token is burnt
     * and the person starts again from a clean one.
     */
    public function reject(Request $request): JsonResponse
    {
        $this->registrar->rejectAccountLinkCandidate(
            $request->user(),
            $request->session()->getId(),
        );

        return response()->json(['state' => 'cancelled']);
    }

    /** The person changed their mind; the intent dies by their own hand. */
    public function cancel(Request $request): JsonResponse
    {
        TelegramLoginIntent::query()
            ->where('purpose', TelegramLoginIntent::PURPOSE_ACCOUNT_LINK)
            ->where('user_id', $request->user()->id)
            ->whereNull('consumed_at')
            ->whereNull('cancelled_at')
            ->get()
            ->each(function (TelegramLoginIntent $intent): void {
                $intent->forceFill([
                    'cancelled_at' => now(),
                    'result' => TelegramLoginIntent::RESULT_CANCELLED,
                ])->save();
            });

        return response()->json(['state' => 'cancelled']);
    }

    /**
     * The intent THIS session is entitled to speak for.
     *
     * Scoped on the session fingerprint in the QUERY rather than fetched
     * and then checked: a different browser session does not get a
     * "pending" answer about somebody else's intent, it gets nothing,
     * because nothing it may see exists.
     */
    private function currentIntent(Request $request): ?TelegramLoginIntent
    {
        return TelegramLoginIntent::query()
            ->where('purpose', TelegramLoginIntent::PURPOSE_ACCOUNT_LINK)
            ->where('user_id', $request->user()->id)
            ->where('session_fingerprint', TelegramLoginIntent::fingerprint($request->session()->getId()))
            ->orderByDesc('id')
            ->first();
    }

    /**
     * @return array<string, mixed>
     */
    private function payload(TelegramLoginIntent $intent): array
    {
        $username = (string) config('services.telegram.bot_username', '');

        return [
            'deep_link' => $username === '' ? null : 'https://t.me/'.$username.'?start='.$intent->token,
            'expires_in_seconds' => max(0, (int) now()->diffInSeconds($intent->expires_at, false)),
            'bot_configured' => $username !== '',
            'requires_confirmation' => TelegramRegistrar::confirmationRequired(),
            'candidate' => $intent->candidatePayload(),
            'candidate_handle' => $intent->candidate_telegram_id === null ? null : $intent->candidateHandle(),
        ];
    }

    private function hash(?string $value): ?string
    {
        return $value === null ? null : hash('sha256', $value);
    }
}
