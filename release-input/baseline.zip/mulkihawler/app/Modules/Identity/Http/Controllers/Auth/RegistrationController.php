<?php

declare(strict_types=1);

namespace App\Modules\Identity\Http\Controllers\Auth;

use App\Http\Middleware\SetLocale;
use App\Modules\Identity\Models\TelegramLoginIntent;
use App\Modules\Identity\Models\User;
use App\Modules\Identity\Services\TelegramRegistrar;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Ordinary-user registration (spec §3): name + phone on the site, then a
 * mandatory Telegram Start to complete.
 *
 * The browser side of this flow can CREATE an intent and OBSERVE it; it can
 * never complete one. Completion happens only on the webhook, behind the
 * secret header — the same separation the login flow already keeps, and for
 * the same reason: if the browser could report "linked", anyone who can post
 * could claim any account.
 */
final class RegistrationController extends Controller
{
    public function __construct(private readonly TelegramRegistrar $registrar) {}

    /**
     * The registration form, or — when this session already holds a live
     * registration intent — the pending screen for it, so a refresh resumes
     * rather than restarts (spec §14: "registration resumes safely").
     */
    public function show(Request $request): Response|RedirectResponse
    {
        if (Auth::check()) {
            return redirect('/');
        }

        $pending = $this->sessionIntent($request);

        return Inertia::render('Auth/Register', [
            'bot_configured' => (string) config('services.telegram.bot_username', '') !== '',
            'pending' => $pending === null ? null : $this->pendingPayload($pending),
            'locales' => ['ckb', 'ar', 'en'],
        ]);
    }

    /**
     * Validate the typed details and mint the registration intent.
     *
     * Phone validation is strict about the ONE thing the blind index needs —
     * a normalisable Iraqi number — and silent about everything else. Telling
     * an attacker which numbers exist is user enumeration, so a number already
     * in use is NOT rejected here; the conflict surfaces at redemption, where
     * the reply is generic and the audit log is specific.
     */
    public function store(Request $request): RedirectResponse
    {
        // Spaces and dashes are how people WRITE numbers, not part of the
        // number. Stripped before validation so "0750 123 4567" is the same
        // input as "07501234567" instead of a rejection.
        $request->merge([
            'phone' => preg_replace('/[\s\-]+/', '', (string) $request->input('phone', '')),
        ]);

        $validated = $request->validate([
            'name' => ['required', 'string', 'min:2', 'max:120'],
            'phone' => ['required', 'string', 'regex:/^(\+?964|0)?7[0-9]{9}$/'],
            'locale' => ['required', 'in:ckb,ar,en'],
            'accept_terms' => ['accepted'],
            'consent_contact' => ['sometimes', 'boolean'],
        ]);

        /*
         * H5 convergence, session-side: this session's PREVIOUS pending
         * registration (held by id, which survives the session-id churn the
         * fingerprint cannot) is cancelled before a new one is minted — a
         * second tab or a re-submission converges on ONE live intent. The
         * registrar's fingerprint sweep remains as defence-in-depth for the
         * same-browser case.
         */
        $this->cancelSessionIntent($request);

        $intent = $this->registrar->begin(
            [
                'name' => trim($validated['name']),
                'phone' => $this->toE164($validated['phone']),
                'locale' => $validated['locale'],
                'consent_contact' => (bool) ($validated['consent_contact'] ?? false),
            ],
            $request->session()->getId(),
            $this->hash($request->ip()),
            $this->hash($request->userAgent()),
        );

        /*
         * The session HOLDS its intent id, rather than the intent holding a
         * session fingerprint alone. Same binding strength — the reference
         * lives inside the session either way — but it survives the session-id
         * churn of test drivers and of `regenerate()`, and it makes the lookup
         * a primary-key read instead of a latest-by-fingerprint scan.
         */
        $request->session()->put('registration_intent_id', $intent->id);

        /*
         * H5: the CHOSEN language, immediately. The person picked a locale
         * on the form; the pending page must already speak it — not the
         * language the form happened to be rendered in. Session first, so
         * every later request agrees; then the redirect lands on the
         * pending page under the right prefix.
         */
        $request->session()->put(SetLocale::SESSION_KEY, $validated['locale']);

        return redirect()->route('register.show');
    }

    /**
     * H5: the person changed their mind — the pending intent dies by their
     * own hand, and the poll reports `cancelled` so every open tab stops.
     */
    public function cancel(Request $request): JsonResponse
    {
        $this->cancelSessionIntent($request);

        return response()->json(['state' => 'cancelled']);
    }

    private function cancelSessionIntent(Request $request): void
    {
        /*
         * By id, not through sessionIntent(): that helper now excludes
         * cancelled intents (and expiry-graces the rest), while cancel must
         * reach an EXPIRED intent too — the pending screen's restart cancels
         * first precisely so the ghost cannot outlive the grace window.
         * Idempotent by construction: a second cancel finds the timestamps
         * already set and writes nothing.
         */
        $id = $request->session()->get('registration_intent_id');

        if (! is_int($id) && ! is_string($id)) {
            return;
        }

        $intent = TelegramLoginIntent::query()
            ->whereKey($id)
            ->where('purpose', TelegramLoginIntent::PURPOSE_REGISTRATION)
            ->first();

        if ($intent !== null && $intent->consumed_at === null && $intent->cancelled_at === null) {
            $intent->forceFill([
                'cancelled_at' => now(),
                'result' => TelegramLoginIntent::RESULT_CANCELLED,
            ])->save();
        }
    }

    /**
     * Has this session's registration been completed by a Start yet?
     *
     * Mirrors the login poll deliberately: the session's own newest intent is
     * the only one visible, no intent id is accepted from the client, and a
     * successful answer performs the sign-in with a session rotation so an id
     * captured before authentication is worthless after it.
     */
    public function poll(Request $request): JsonResponse
    {
        $intent = $this->sessionIntent($request, consumedToo: true, cancelledToo: true);

        if ($intent === null) {
            return response()->json(['state' => 'pending', 'completed' => false]);
        }

        /*
         * H5: a NAMED state for every way this can end, so nobody polls a
         * corpse. Conflict deliberately says nothing about WHICH identifier
         * collided; the recovery it offers is the returning Telegram login —
         * an existing account's own door — never a merge.
         */
        if ($intent->result === TelegramLoginIntent::RESULT_CONFLICT) {
            return response()->json([
                'state' => 'conflict',
                'completed' => false,
                'recovery' => localized_route('telegram.login', locale: $intent->locale),
            ]);
        }

        if ($intent->cancelled_at !== null) {
            return response()->json(['state' => 'cancelled', 'completed' => false]);
        }

        if ($intent->consumed_at === null || $intent->user_id === null) {
            if (! $intent->expires_at->isFuture()) {
                return response()->json(['state' => 'expired', 'completed' => false]);
            }

            return response()->json(['state' => 'pending', 'completed' => false]);
        }

        $user = User::query()->find($intent->user_id);

        // H4: the ONE rule. A suspended account does not get signed in by
        // its own registration completing — same quiet non-answer as any
        // other pending state, no existence signal.
        if ($user === null || ! $user->mayAuthenticate()) {
            return response()->json(['state' => 'pending', 'completed' => false]);
        }

        $request->session()->regenerate();

        Auth::login($user, remember: true);

        return response()->json([
            'state' => 'completed',
            'completed' => true,
            // The person chose their language on the form; the intent
            // remembers it, and the landing page must speak it (§6.6).
            'redirect' => localized_route('account.onboarding', locale: $intent->locale),
        ]);
    }

    /**
     * The newest registration intent bound to this session's fingerprint.
     */
    private function sessionIntent(Request $request, bool $consumedToo = false, bool $cancelledToo = false): ?TelegramLoginIntent
    {
        $id = $request->session()->get('registration_intent_id');

        if (! is_int($id) && ! is_string($id)) {
            return null;
        }

        $query = TelegramLoginIntent::query()
            ->whereKey($id)
            ->where('purpose', TelegramLoginIntent::PURPOSE_REGISTRATION)
            // A short grace past expiry so the pending screen can SAY it
            // expired instead of silently showing a fresh form.
            ->where('expires_at', '>', now()->subMinutes(5));

        if (! $consumedToo) {
            $query->whereNull('consumed_at');
        }

        /*
         * Cancelled is TERMINAL for the SHOW path: the person ended it, and
         * the restart contract is that a revisit renders a fresh form — a
         * cancelled intent must never haunt the next page load. (The
         * browser matrix found the ghost.) The POLL path opts back in,
         * because "the browser sees cancelled without guessing" is its own
         * correction, and reporting a state requires seeing it.
         */
        if (! $cancelledToo) {
            $query->whereNull('cancelled_at');
        }

        return $query->first();
    }

    /** @return array<string, mixed> */
    private function pendingPayload(TelegramLoginIntent $intent): array
    {
        $username = (string) config('services.telegram.bot_username', '');

        return [
            'deep_link' => $username === ''
                ? null
                : sprintf('https://t.me/%s?start=%s', $username, $intent->token),
            'expires_in_seconds' => max(0, now()->diffInSeconds($intent->expires_at, false)),
            'name' => $intent->registration_name,
        ];
    }

    /**
     * `+9647XXXXXXXXX`, from any of the ways an Iraqi number is written.
     * Must agree with the authenticator's normalisation or the same person
     * gets two blind indexes.
     */
    private function toE164(string $phone): string
    {
        $digits = preg_replace('/[^0-9]/', '', $phone) ?? '';
        $digits = ltrim($digits, '0');

        if (! str_starts_with($digits, '964')) {
            $digits = '964'.$digits;
        }

        return '+'.$digits;
    }

    private function hash(?string $value): ?string
    {
        return $value === null ? null : hash('sha256', $value);
    }
}
